/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import cst8218.chaa0026.bouncer.entity.Bouncer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Zahi Masarwa & Mohamad Chaaban 
 */
public class BouncerTest {
    
    public BouncerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    // Test method to check the behavior of the bouncer when it's stationary at the bottom of the frame
    @Test
    void testAdvanceOneFrameStationary() {
        // Create a new Bouncer instance
        Bouncer bouncer = new Bouncer();
        
        // Set initial position and speed for the bouncer
        bouncer.setY(Bouncer.FRAME_HEIGHT);
        bouncer.setySpeed(0);

        // Advance the bouncer by one frame
        bouncer.advanceOneFrame();

        // Check if the bouncer will collide with the bottom of the frame
        assertTrue(bouncer.willCollide());
        
        // Check if the bouncer's position and speed are maintained
        assertEquals(Bouncer.FRAME_HEIGHT, bouncer.getY());
        assertEquals(0, bouncer.getySpeed());
    }
    
    // Test method to check the behavior of the bouncer when it collides with an object
    @Test
    void testAdvanceOneFrameCollision() {
        // Create a new Bouncer instance
        Bouncer bouncer = new Bouncer();
        
        // Set initial position and speed for the bouncer
        bouncer.setY(Bouncer.FRAME_HEIGHT - 1);
        bouncer.setySpeed(2);

        // Advance the bouncer by one frame
        bouncer.advanceOneFrame();

        // Check if the bouncer will not collide with any object
        assertFalse(bouncer.willCollide());
        
        // Check if the bouncer's position is maintained and speed becomes 0
        assertEquals(Bouncer.FRAME_HEIGHT - 1, bouncer.getY());
        assertEquals(0, bouncer.getySpeed());
    }
    
    // Test method to check the behavior of the bouncer under gravity
    @Test
    void testAdvanceOneFrameGravity() {
        // Create a new Bouncer instance
        Bouncer bouncer = new Bouncer();
        
        // Set initial position and speed for the bouncer
        bouncer.setY(Bouncer.FRAME_HEIGHT - 10);
        bouncer.setySpeed(5);

        // Advance the bouncer by one frame
        bouncer.advanceOneFrame();

        // Check if the bouncer will collide with the bottom of the frame
        assertTrue(bouncer.willCollide());
        
        // Check if the bouncer's position is adjusted due to gravity and speed changes
        assertEquals(Bouncer.FRAME_HEIGHT - 5, bouncer.getY());
        assertEquals(6, bouncer.getySpeed());
    }
    
    // Test method to check the behavior of the bouncer when it collides with the ceiling
    @Test
    void testAdvanceOneFrameCeilingCollision() {
        // Create a new Bouncer instance
        Bouncer bouncer = new Bouncer();
        
        // Set initial position and speed for the bouncer
        bouncer.setY(1);
        bouncer.setySpeed(-2);

        // Advance the bouncer by one frame
        bouncer.advanceOneFrame();

        // Check if the bouncer will not collide with the ceiling
        assertFalse(bouncer.willCollide());
        
        // Check if the bouncer's position is maintained and speed changes
        assertEquals(1, bouncer.getY());
        assertEquals(2, bouncer.getySpeed());
    }
}
