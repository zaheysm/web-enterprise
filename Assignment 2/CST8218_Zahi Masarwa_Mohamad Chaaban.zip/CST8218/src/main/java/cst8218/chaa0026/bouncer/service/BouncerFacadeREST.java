/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.chaa0026.bouncer.service;

import cst8218.chaa0026.bouncer.entity.Bouncer;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.security.enterprise.authentication.mechanism.http.BasicAuthenticationMechanismDefinition;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 * Facade for the restful api
 * @author Zahi Masarwa & Mohamad Chaaban 
 */
@Stateless
@Path("cst8218.chaa0026.bouncer.entity.bouncer")
@BasicAuthenticationMechanismDefinition 
@DeclareRoles("ApiGroup")
public class BouncerFacadeREST extends AbstractFacade<Bouncer> {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    public BouncerFacadeREST() {
        super(Bouncer.class);
    }

    /**
     * Creates a new bouncer from the entity passed by the user
     * @param entity the object to be created
     * @param uriInfo the URI info object to get the location
     * @return response and the object if created
     */
    @POST
    @RolesAllowed("ApiGroup")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response createBouncer(Bouncer entity, @Context UriInfo uriInfo) {
        URI location = null;
        try {
            location = new URI(uriInfo.getRequestUri().getPath() + "/" + entity.getId());
        } catch (URISyntaxException e) {
            Logger.getLogger(BouncerFacadeREST.class.getName()).log(Level.SEVERE, null, e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).location(location).entity(e.getMessage()).build(); // send server error response if something goes wrong
        }
        if (entity.getId() != null) { // if the id is not null then return a bad request
            return Response.status(Response.Status.BAD_REQUEST).location(location).build();
        }
        if (entity.getX() != null) { // make sure x isn't null
            if (entity.getX() < 0 || entity.getX() > Bouncer.FRAME_WIDTH) { // see if out of bounds
                return Response.status(Response.Status.CONFLICT).location(location).entity("Bouncer x value is out of bounds").build();
            }
        }
        if (entity.getY() != null) { // make sure x isn't null
            if (entity.getY() < 0 || entity.getY() > Bouncer.FRAME_HEIGHT) { // see if out of bounds
                return Response.status(Response.Status.CONFLICT).location(location).entity("Bouncer y value is out of bounds").build();
            }
        }
        entity.init(); // set the null properties
        try {
            super.create(entity); // create the entity in the database
            return Response.status(Response.Status.CREATED).location(location).entity(entity).build(); // return Created response with entity in body
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).location(location).entity(e.getMessage()).build(); // send server error response if something goes wrong
        }
    }

    /**
     * Updates bouncer with id passed
     * @param id id of the bouncer to be updated
     * @param entity values to be updated
     * @param uriInfo the URI info object to get the location
     * @return response with the updated bouncer
     */
    @POST
    @Path("{id}")
    @RolesAllowed("ApiGroup")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response updateBouncer(@PathParam("id") Long id, Bouncer entity, @Context UriInfo uriInfo) {
        URI location = null;
        try {
            location = new URI(uriInfo.getRequestUri().getPath() + "/" + entity.getId());
        } catch (URISyntaxException e) {
            Logger.getLogger(BouncerFacadeREST.class.getName()).log(Level.SEVERE, null, e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).location(location).entity(e.getMessage()).build(); // send server error response if something goes wrong
        }
        Bouncer bouncer = super.find(id);
        if (bouncer == null) { // if bouncer is null then say it's not found
            return Response.status(Response.Status.NOT_FOUND).location(location).entity("Bouncer with id " + id + " not found").build();
        }
        if (entity.getId() != null && !entity.getId().equals(bouncer.getId())) { // if the id doesn't match then it's a bad request
            return Response.status(Response.Status.BAD_REQUEST).location(location).entity("Bouncer id in the request body does not match the path parameter").build();
        }
        if (entity.getX() != null) { // make sure x isn't null
            if (entity.getX() < 0 || entity.getX() > Bouncer.FRAME_WIDTH) { // see if out of bounds
                return Response.status(Response.Status.CONFLICT).location(location).entity("Bouncer x value is out of bounds").build();
            }
        }
        if (entity.getY() != null) { // make sure y isn't null
            if (entity.getY() < 0 || entity.getY() > Bouncer.FRAME_HEIGHT) { // see if out of bounds
                return Response.status(Response.Status.CONFLICT).location(location).entity("Bouncer y value is out of bounds").build();
            }
        }
        bouncer.update(entity); // update the bouncer with the entity values
        try {
            super.edit(bouncer); // edit the bouncer
            return Response.ok(bouncer).location(location).build(); // send ok response with bouncer in body
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).location(location).entity(e.getMessage()).build(); // send server error response if something goes wrong
        }
    }

    /**
     * Edits a bouncer with the id passed
     * @param id id of bouncer to be edited
     * @param entity values to be edited
     * @param uriInfo the URI info object to get the location
     * @return response with no content
     */
    @PUT
    @Path("{id}")
    @RolesAllowed("ApiGroup")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response edit(@PathParam("id") Long id, Bouncer entity, @Context UriInfo uriInfo) {
        URI location = null;
        try {
            location = new URI(uriInfo.getRequestUri().getPath() + "/" + entity.getId());
        } catch (URISyntaxException e) {
            Logger.getLogger(BouncerFacadeREST.class.getName()).log(Level.SEVERE, null, e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).location(location).entity(e.getMessage()).build(); // send server error response if something goes wrong
        }
        Bouncer oldBouncer = super.find(id);
        if (oldBouncer == null) { // if bouncer is null then say it's not found
            return Response.status(Response.Status.NOT_FOUND).location(location).entity("Bouncer with id " + id + " not found").build();
        }
        if (entity.getId() != null && !entity.getId().equals(oldBouncer.getId())) { // if the id doesn't match then it's a bad request
            return Response.status(Response.Status.BAD_REQUEST).location(location).entity("Bouncer id in the request body does not match the path parameter").build();
        }
        if (entity.getX() != null) { // make sure x isn't null
            if (entity.getX() < 0 || entity.getX() > Bouncer.FRAME_WIDTH) { // see if out of bounds
                return Response.status(Response.Status.CONFLICT).location(location).entity("Bouncer x value is out of bounds").build();
            }
        }
        if (entity.getY() != null) { // make sure y isn't null
            if (entity.getY() < 0 || entity.getY() > Bouncer.FRAME_HEIGHT) { // see if out of bounds
                return Response.status(Response.Status.CONFLICT).location(location).entity("Bouncer y value is out of bounds").build();
            }
        }
        try {
            // replace the old bouncer with the new one
            entity.setId(oldBouncer.getId());
            entity.init();
            super.edit(entity); // save the new one in the database
            return Response.noContent().location(location).build(); // return a no content response to tell them we succeeded
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).location(location).entity(e.getMessage()).build(); // send server error response if something goes wrong
        }
    }

    /**
     * Edit all is not a valid call
     * @param entities the object passed by the user
     * @return method not allowed response
     */
    @PUT
    @RolesAllowed("ApiGroup")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response editAll(Bouncer entities) {
        return Response.status(Response.Status.METHOD_NOT_ALLOWED).entity("PUT on root resource is not allowed").build(); // send method not allowed
    }

    @DELETE
    @Path("{id}")
    @RolesAllowed("ApiGroup")
    public void remove(@PathParam("id") Long id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @RolesAllowed("ApiGroup")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Bouncer find(@PathParam("id") Long id) {
        return super.find(id);
    }

    @GET
    @Override
    @RolesAllowed("ApiGroup")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Bouncer> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @RolesAllowed("ApiGroup")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Bouncer> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @RolesAllowed("ApiGroup")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

}
