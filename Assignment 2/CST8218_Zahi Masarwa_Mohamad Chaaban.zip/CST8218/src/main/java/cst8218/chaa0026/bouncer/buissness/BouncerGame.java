/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.chaa0026.bouncer.buissness;

import cst8218.chaa0026.bouncer.entity.Bouncer;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

/**
 * Bouncer Game singleton where the game loop is and it runs at startup
 * @author @author Zahi Masarwa & Mohamad Chaaban 
 */
@Startup
@Singleton
public class BouncerGame {

    @Inject
    private BouncerFacade bouncerFacade;
    private List<Bouncer> bouncers;
    private static final int CHANGE_RATE = 1;

    /**
     * Method that starts the new thread where the game loop will be
     */
    @PostConstruct
    public void go() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                // the game runs indefinitely
                while (true) {
                    //update all the bouncers and save changes to the database
                    bouncers = bouncerFacade.findAll();
                    for (Bouncer bouncer : bouncers) {
                        bouncer.advanceOneFrame();
                        bouncerFacade.edit(bouncer);
                    }
                    //sleep while waiting to process the next frame of the animation
                    try {
                        // wake up roughly CHANGE_RATE times per second
                        Thread.sleep((long) (1.0 / CHANGE_RATE * 1000));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
}