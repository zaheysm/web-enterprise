/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.chaa0026.bouncer.entity;

import java.io.Serializable;
import java.util.Optional;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.security.enterprise.identitystore.DatabaseIdentityStoreDefinition;
import javax.security.enterprise.identitystore.PasswordHash;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

/**
 * Bouncer entity
 *
 * @author Zahi Masarwa & Mohamad Chaaban 
 */
@Entity
@DatabaseIdentityStoreDefinition(
   dataSourceLookup = "${'java:comp/DefaultDataSource'}",
   callerQuery = "#{'select password from app.appuser where userid = ?'}",
   groupsQuery = "select groupname from app.appuser where userid = ?",
   hashAlgorithm = PasswordHash.class,
   priority = 10
)
public class Bouncer implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final int GRAVITY_ACCEL = 1;
    private static final int DECAY_RATE = 1;

    /**
     * the set frame height of the game
     */
    public static final int FRAME_HEIGHT = 500;

    /**
     * the set frame width of the game
     */
    public static final int FRAME_WIDTH = 500;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Min(0)
    @Max(FRAME_WIDTH)
    private Integer x;
    @Min(0)
    @Max(FRAME_HEIGHT)
    private Integer y;
    private Integer ySpeed;

    /**
     * gets the id
     * @return id
     */
    public Long getId() {
        return id;
    }

    /**
     * sets id
     * @param id id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * gets x
     * @return x
     */
    public Integer getX() {
        return x;
    }

    /**
     * sets x
     * @param x x to set
     */
    public void setX(Integer x) {
        this.x = x;
    }

    /**
     * gets y
     * @return y
     */
    public Integer getY() {
        return y;
    }

    /**
     * sets y
     * @param y y to set
     */
    public void setY(Integer y) {
        this.y = y;
    }

    /**
     * gets ySpeed
     * @return ySpeed
     */
    public Integer getySpeed() {
        return ySpeed;
    }

    /**
     * sets ySpeed
     * @param ySpeed ySpeed to set
     */
    public void setySpeed(Integer ySpeed) {
        this.ySpeed = ySpeed;
    }

    /**
     * Updates the fields of this object that correspond to a non null property in bouncer object
     * @param bouncer bouncer to update with
     */
    public void update(Bouncer bouncer) {
        this.setX(Optional.ofNullable(bouncer.getX()).orElse(this.getX()));
        this.setY(Optional.ofNullable(bouncer.getY()).orElse(this.getY()));
        this.setySpeed(Optional.ofNullable(bouncer.getySpeed()).orElse(this.getySpeed()));
    }

    /**
     * Inits the bouncer, if a property is null then it is put to 0 else we keep it
     */
    public void init() {
        this.setX(Optional.ofNullable(this.getX()).orElse(0));
        this.setY(Optional.ofNullable(this.getY()).orElse(0));
        this.setySpeed(Optional.ofNullable(this.getySpeed()).orElse(0));
    }

    /**
     * Updates the properties to simulate the passing of one unit of time
     */
    public void advanceOneFrame() {
        if (isStationary()) { // do nothing if it's stationary
            return;
        }
        if (willCollide()) { // if it will collide then bounce the bouncer
            bounceTheBouncer();
        }
        if (!isStationary()) { // if it's not stationary then add the gravity effect
            addGravityEffect();
        }
    }

    /**
     * Checks if the bouncer is stationary at the bottom of the screen
     *
     * @return true if it's stationary and false otherwise
     */
    private boolean isStationary() {
        return y == FRAME_HEIGHT && ySpeed == 0;
    }

    /**
     * Detects if there will be a collision with a surface
     *
     * @return true if there will be a collision, false otherwise
     */
    public boolean willCollide() {
        int resultingY = y + ySpeed;
        return resultingY >= FRAME_HEIGHT || resultingY <= 0;
    }

    /**
     * Adds the effects of gravity to the object
     */
    public void addGravityEffect() {
        y += ySpeed;
        ySpeed += GRAVITY_ACCEL;
    }

    /**
     * Bounces the Bouncer object off of surfaces (ground or ceiling)
     */
    public void bounceTheBouncer() {
        y = (ySpeed > 0) ? FRAME_HEIGHT : 0;
        // Make sure we're reducing the ySpeed by decay and not accedintly increasing it
        ySpeed = (ySpeed > 0) ? ySpeed - DECAY_RATE : ySpeed + DECAY_RATE;
        ySpeed = -ySpeed;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bouncer)) {
            return false;
        }
        Bouncer other = (Bouncer) object;
        return !((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)));
    }

    @Override
    public String toString() {
        return "cst8218.chaa0026.bouncer.entity.Bouncer[ id=" + id + ", x=" + x + ", y=" + y + ", ySpeed=" + ySpeed + " ]";
    }
}
